<!DOCTYPE html>

<!--
 // WEBSITE: https://themefisher.com
 // TWITTER: https://twitter.com/themefisher
 // FACEBOOK: https://www.facebook.com/themefisher
 // GITHUB: https://github.com/themefisher/
-->

<html lang="zxx">

<head>
  <meta charset="utf-8">
  <title>Votação</title>

  <!-- mobile responsive meta -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  
  <!-- ** Plugins Needed for the Project ** -->
  <!-- plugins -->
  <link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="plugins/themify-icons/themify-icons.css">
  <!-- Main Stylesheet -->
  <link href="css/style.css" rel="stylesheet">
  
  <!--Favicon-->
  <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
  <link rel="icon" href="images/favicon.ico" type="image/x-icon">

</head>

<body>

<header class="sticky-top navigation">
  <div class=container>
    <nav class="navbar navbar-expand-lg navbar-light bg-transparent">
      <div>
		  <h3 href="principal.php" id="heading-2">VoteNow</h3>
		  <a href="principal.php" class="stretched-link"></a>
		</div>
      <button class="navbar-toggler border-0" type="button" data-toggle="collapse" data-target="#navigation">
        <i class="ti-align-right h4 text-dark"></i></button>
      <div class="collapse navbar-collapse text-center" id=navigation>
        <ul class="navbar-nav mx-auto align-items-center"></ul>
        <a href="index.php" class="btn btn-sm btn-outline-primary ml-lg-4">Dashboard</a>
        <a href="login.php" class="btn btn-sm btn-primary ml-lg-4">Entrar</a>
      </div>
    </nav>
  </div>
</header>

<section class="section pb-0">
  <div class="container">
    <h2 class="mb-5 font-weight-medium">Titulo da votação</h2>
    <div class="row">
      <!-- topic -->
      <div class="col-lg-4 col-md-4 col-sm-6 mb-4">
        <div class="card match-height">
          <div class="card-body">
            <h3 class="card-text h4 text-center mb-4">Texto da opção</h3>
			<button type="submit" class="btn btn-primary">Votar</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>	

<footer>
  <div class="container">
    <div class="row align-items-center border-bottom py-5"></div>
    <div class="py-4 text-center">
      <small class="text-light">Copyright © 2020 a hugo theme by <a href="https://themefisher.com">themefisher</a></small>
    </div>
  </div>
</footer>
	
<!-- plugins -->
<script src="plugins/jQuery/jquery.min.js"></script>
<script src="plugins/bootstrap/bootstrap.min.js"></script>
<script src="plugins/masonry/masonry.min.js"></script>
<script src="plugins/clipboard/clipboard.min.js"></script>
<script src="plugins/match-height/jquery.matchHeight-min.js"></script>

<!-- Main Script -->
<script src="js/script.js"></script>

</body>
</html>