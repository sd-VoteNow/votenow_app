<!DOCTYPE html>

<!--
 // WEBSITE: https://themefisher.com
 // TWITTER: https://twitter.com/themefisher
 // FACEBOOK: https://www.facebook.com/themefisher
 // GITHUB: https://github.com/themefisher/
-->

<html lang="zxx">

<head>
  <meta charset="utf-8">
  <title>VoteNow</title>

  <!-- mobile responsive meta -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  
  <!-- theme meta -->
  <meta name="theme-name" content="godocs" />
  
  <!-- ** Plugins Needed for the Project ** -->
  <!-- plugins -->
  <link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="plugins/themify-icons/themify-icons.css">
  <!-- Main Stylesheet -->
  <link href="css/style.css" rel="stylesheet">
  
  <!--Favicon-->
  <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
  <link rel="icon" href="images/favicon.ico" type="image/x-icon">

</head>

<body>

<header class="sticky-top navigation">
  <div class=container>
    <nav class="navbar navbar-expand-lg navbar-light bg-transparent">
      <div>
		  <h3 href="principal.php" id="heading-2">VoteNow</h3>
		  <a href="principal.php" class="stretched-link"></a>
		</div>
      <button class="navbar-toggler border-0" type="button" data-toggle="collapse" data-target="#navigation">
        <i class="ti-align-right h4 text-dark"></i></button>
      <div class="collapse navbar-collapse text-center" id=navigation>
        <ul class="navbar-nav mx-auto align-items-center"></ul>
        <a href="index.php" class="btn btn-sm btn-outline-primary ml-lg-4">Dashboard</a>
        <a href="login.php" class="btn btn-sm btn-primary ml-lg-4">Entrar</a>
      </div>
    </nav>
  </div>
</header>

<!-- banner -->
<section class="section pb-0">
  <div class="container">
    <div class="row justify-content-between align-items-center">
      <div class="col-lg-7 text-center text-lg-left">
        <h1 class="mb-4">Uma plataforma onde podes votar online&nbsp;</h1>
        <p class="mb-4">Com o VoteNow podes votar em diversos âmbito como concursos, decisões, etc. Cria a tua conta e começa a votar!&nbsp; &nbsp;</p>
      </div>
      <div class="col-lg-4 d-lg-block d-none">
        <img src="images/banner.jpg" alt="illustration" class="img-fluid">
      </div>
    </div>
  </div>
</section>
<!-- /banner -->

<!-- topics -->
<section class="section pb-0">
  <div class="container">
    <h2 class="section-title text-primary">Votações ativas</h2>
    <div class="row">
      <!-- topic -->
      <div class="col-lg-4 col-md-4 col-sm-6">
        <div class="card match-height">
          <div class="card-body">
            <h3 class="card-title h4">Titulo da votação</h3>
            <a href="votacao.php" class="stretched-link"></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- /topics -->

<footer>
  <div class="container">
    <div class="row align-items-center border-bottom py-5"></div>
    <div class="py-4 text-center">
      <small class="text-light">Copyright © 2020 a hugo theme by <a href="https://themefisher.com">themefisher</a></small>
    </div>
  </div>
</footer>

<!-- plugins -->
<script src="plugins/jQuery/jquery.min.js"></script>
<script src="plugins/bootstrap/bootstrap.min.js"></script>
<script src="plugins/masonry/masonry.min.js"></script>
<script src="plugins/clipboard/clipboard.min.js"></script>
<script src="plugins/match-height/jquery.matchHeight-min.js"></script>

<!-- Main Script -->
<script src="js/script.js"></script>

</body>
</html>
