<?php 
session_start();     
if(isset($_SESSION['email'])) 
{
  if(isset($_SESSION['pass']))
  {             
    $_SESSION["email"]=$_SESSION["email"];
    $_SESSION["pass"]=$_SESSION["pass"];
}
}
?>
<?php
function post($url,$data) {
    /* Init cURL resource */
    $ch = curl_init($url);

    /* pass encoded JSON string to the POST fields */
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    /* set the content type json */
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

    /* set return type json */
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    /* execute request */
    return curl_exec($ch);
}
?>


<?php
$id=0;          
$data = ["email" => $_SESSION["email"],"pass" => $_SESSION["pass"]];  
$someJSON = post('http://192.168.30.1:3010/resultvot',$data);
if( $someJSON == "[]") {echo "a pagina nao tem elementos";
} else { 
  $arr = json_decode($someJSON, true); 
}   
?>

<?php
$qtd = 0;
$id = $_POST["id"];
//print $_POST["voto"];
?>

<?php 

for ($i = 0; $i < sizeof($arr); $i++) {
if($id == $arr[$i]["perguntas_id"]) { $id = $arr[$i]["perguntas_id"];
$qtd += $arr[$i]["quantidade_respostas"];
} 
} 

?>







<!DOCTYPE html>
<html :class="{ 'theme-dark': dark }" x-data="data()" lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Windmill Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="./css/tailwind.output.css" />
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js"
      defer></script>
    <script src="./js/init-alpine.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css"/>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"
      defer
    ></script>
    <script src="./js/charts-lines.js" defer></script>
    <script src="./js/charts-pie.js" defer></script>
    <script>
    $(document).ready(function(){
        $("#modal").modal('show');
    });
</script>
  </head>
 
  <body>    
    <div class="flex h-screen bg-white-50" :class="{ 'overflow-hidden': isSideMenuOpen }">
      <!-- Desktop sidebar -->
      <aside
        class="z-20 hidden w-64 overflow-y-auto bg-white md:block flex-shrink-0"
      >
        <div class="py-4 text-gray-500 ">
          <a
            class="ml-6 text-lg font-bold text-gray-800"
            href="index.php"
          >
          VoteNow
        </a>
          <ul class="mt-6">
            <li class="relative px-6 py-3">             
              <a class="inline-flex items-center w-full text-sm font-semibold transition-colors duration-150 hover:text-gray-800"
                href="desh.php">
                <svg class="w-5 h-5" aria-hidden="true" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor">
					<path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path>
			  </svg>
                <span class="ml-4">Votações</span>
              </a>
            </li>
          </ul>
          <ul>
            <li class="relative px-6 py-3">
              <a class="inline-flex items-center w-full text-sm font-semibold transition-colors duration-150 hover:text-gray-800"
                href="forms.php">
                <svg class="w-5 h-5" aria-hidden="true" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor">
					<path d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
                <span class="ml-4">Criar votação</span>
              </a>
            </li>
          </ul>
			<ul>
            <li class="relative px-6 py-3">
              <a class="inline-flex items-center w-full text-sm font-semibold transition-colors duration-150 hover:text-gray-800"
                href="index.php">
                <svg class="w-5 h-5" aria-hidden="true" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor" >
					<path d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"></path></svg>
                <span class="ml-4">Terminar Sessão</span>
              </a>
            </li>
          </ul>
          <div class="px-6 my-6">
            <a href="index.php" class="flex items-center justify-between w-full px-4 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-red-600 border border-transparent rounded-lg active:bg-red-600 hover:bg-red-700 focus:outline-none focus:shadow-outline-red">Página de votações</a>
          </div>
        </div>
      </aside>
      <!-- Backdrop -->
      <div
        x-show="isSideMenuOpen"
        x-transition:enter="transition ease-in-out duration-150"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        x-transition:leave="transition ease-in-out duration-150"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
        class="fixed inset-0 z-10 flex items-end bg-black bg-opacity-50 sm:items-center sm:justify-center"
      ></div>
      <div class="flex flex-col flex-1 w-full">
        <main class="h-full overflow-y-auto">
          <div class="container px-6 mx-auto grid">
            <h2 class="my-6 text-2xl font-semibold text-gray-700">
              Respostas
            </h2>

            <!-- New Table -->
            <div class="w-full overflow-hidden rounded-lg shadow-xs">
              <div class="w-full overflow-x-auto">
                <table class="w-full whitespace-no-wrap">
                  <thead>
					            <tr class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b bg-gray-50">
                      <th class="px-4 py-3">Título da Resposta</th>
                      <th class="px-4 py-3">Votos</th>
                      <th class="px-4 py-3">percentagem</th>
                    </tr>
                  </thead>
                  <tbody class="bg-white divide-y">


                 
              
  
        
                  <?php for ($i = 0; $i < sizeof($arr); $i++) {?>
                    <?php if($id == $arr[$i]["perguntas_id"]) { $id = $arr[$i]["perguntas_id"];?>
                    <tr class="text-gray-700">
                      
                      <td class="px-4 py-3 text-sm"><?php print $arr[$i]["respostas"];?></td>
                      <td class="px-4 py-3 text-sm"><?php print $arr[$i]["quantidade_respostas"];?></td>
                      <td class="px-4 py-3 text-sm"><?php print ($arr[$i]["quantidade_respostas"]/$qtd)*100;?>%</td>
                    </tr>
                    <?php } ?>
                  <?php } ?>





                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
	
	  <div
      x-show="isModalOpen"
      x-transition:enter="transition ease-out duration-150"
      x-transition:enter-start="opacity-0"
      x-transition:enter-end="opacity-100"
      x-transition:leave="transition ease-in duration-150"
      x-transition:leave-start="opacity-100"
      x-transition:leave-end="opacity-0"
      class="fixed inset-0 z-30 flex items-end bg-black bg-opacity-50 sm:items-center sm:justify-center"
    >





    
      <!-- Modal -->
      <div
        x-show="isModalOpen"
        x-transition:enter="transition ease-out duration-150"
        x-transition:enter-start="opacity-0 transform translate-y-1/2"
        x-transition:enter-end="opacity-100"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0  transform translate-y-1/2"
        @click.away="closeModal"
        @keydown.escape="closeModal"
        class="px-6 py-4 overflow-hidden bg-white rounded-t-lg sm:rounded-lg sm:m-4 sm:max-w-xl w-100"
        role="dialog"
        id="modal"
      >
        <!-- Remove header if you don't want a close icon. Use modal body to place modal tile. -->
        <header class="flex justify-end">
          <button
            class="inline-flex items-center justify-center w-6 h-6 text-gray-400 transition-colors duration-150 rounded hover: hover:text-gray-700"
            aria-label="close"
            @click="closeModal"
          >
            <svg
              class="w-4 h-4"
              fill="currentColor"
              viewBox="0 0 20 20"
              role="img"
              aria-hidden="true"
            >
              <path
                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                clip-rule="evenodd"
                fill-rule="evenodd"
              ></path>
            </svg>
          </button>
        </header>
        <!-- Modal body -->
        <div class="mt-4 mb-6">
          <!-- Modal title -->
          <p
            class="mb-2 text-lg font-semibold text-gray-700"
          >
            Resultados da votação
          </p>
          <!-- Modal description -->
          <div class="w-full overflow-hidden rounded-lg shadow-xs">
              <div class="w-full overflow-x-auto">
                <table class="w-full whitespace-no-wrap">
                  <thead>
					            <tr class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b bg-gray-50">
                      <th class="px-4 py-3">Opção</th>
                      <th class="px-4 py-3">Votos</th>
                      <th class="px-4 py-3">%</th>
                    </tr>
                  </thead>

                  <tbody class="bg-white divide-y">
                    <tr class="text-gray-700">
                      <td class="px-4 py-3">
                        <div class="flex items-center text-sm">
                          <!-- Avatar with inset shadow -->
                          <div>
                            <p class="font-semibold">Texto da opção/resposta1</p>
                          </div>
                        </div>
                      </td>
                      <td class="px-4 py-3 text-sm">3</td>
                      <td class="px-4 py-3 text-sm">100</td>
                    </tr>
                  </tbody>

                </table>
              </div>
            </div>
        </div>
      </div>






<!-- Modal2 -->
<div
        x-show="isModalOpen"
        x-transition:enter="transition ease-out duration-150"
        x-transition:enter-start="opacity-0 transform translate-y-1/2"
        x-transition:enter-end="opacity-100"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0  transform translate-y-1/2"
        @click.away="closeModal"
        @keydown.escape="closeModal"
        class="px-6 py-4 overflow-hidden bg-white rounded-t-lg sm:rounded-lg sm:m-4 sm:max-w-xl w-100"
        role="dialog"
        id="modal2"
      >
        <!-- Remove header if you don't want a close icon. Use modal body to place modal tile. -->
        <header class="flex justify-end">
          <button
            class="inline-flex items-center justify-center w-6 h-6 text-gray-400 transition-colors duration-150 rounded hover: hover:text-gray-700"
            aria-label="close"
            @click="closeModal"
          >
            <svg
              class="w-4 h-4"
              fill="currentColor"
              viewBox="0 0 20 20"
              role="img"
              aria-hidden="true"
            >
              <path
                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                clip-rule="evenodd"
                fill-rule="evenodd"
              ></path>
            </svg>
          </button>
        </header>
        <!-- Modal body -->
        <div class="mt-4 mb-6">
          <!-- Modal title -->
          <p
            class="mb-2 text-lg font-semibold text-gray-700"
          >
            Resultados da votação2
          </p>
          <!-- Modal description -->
          <div class="w-full overflow-hidden rounded-lg shadow-xs">
              <div class="w-full overflow-x-auto">
                <table class="w-full whitespace-no-wrap">
                  <thead>
					            <tr class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b bg-gray-50">
                      <th class="px-4 py-3">Opção2</th>
                      <th class="px-4 py-3">Votos2</th>
                      <th class="px-4 py-3">%</th>
                    </tr>
                  </thead>

                  <tbody class="bg-white divide-y">
                    <tr class="text-gray-700">
                      <td class="px-4 py-3">
                        <div class="flex items-center text-sm">
                          <!-- Avatar with inset shadow -->
                          <div>
                            <p class="font-semibold">Texto da opção/resposta2</p>
                          </div>
                        </div>
                      </td>
                      <td class="px-4 py-3 text-sm">3</td>
                      <td class="px-4 py-3 text-sm">100</td>
                    </tr>
                  </tbody>

                </table>
              </div>
            </div>
        </div>
      </div>



    



    </div>
  </body>
</html>
