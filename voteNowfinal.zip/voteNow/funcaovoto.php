<
<?php 
session_start();     
if(isset($_SESSION['email'])) 
{
  if(isset($_SESSION['pass']))
  {             
    $_SESSION["email"]=$_SESSION["email"];
    $_SESSION["pass"]=$_SESSION["pass"];
}
}
?>
<?php
function post($url,$data) {
    /* Init cURL resource */
    $ch = curl_init($url);

    /* pass encoded JSON string to the POST fields */
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    /* set the content type json */
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

    /* set return type json */
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    /* execute request */
    return curl_exec($ch);
}
?>




<?php
$data = $_POST["voto"];
print $_POST["voto"];
?>





<?php   
if(isset($_SESSION['email'])) 
{
  if(isset($_SESSION['pass']))
  {             
    $data = ["email" => $_SESSION["email"],"pass" => $_SESSION["pass"],"resposta_id" => $_POST["voto"]];  
    post('http://votenowapi.zapto.org/voto',$data);
    header("Location: " . "index.php");
}else{header("Location: " . "login.php");}
}else{header("Location: " . "login.php");} 
?>