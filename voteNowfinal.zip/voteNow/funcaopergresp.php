<?php 
session_start();     
if(isset($_SESSION['email'])) 
{
  if(isset($_SESSION['pass']))
  {             
    $_SESSION["email"]=$_SESSION["email"];
    $_SESSION["pass"]=$_SESSION["pass"];
}
}
?>
<?php
function post($url,$data) {
    /* Init cURL resource */
    $ch = curl_init($url);

    /* pass encoded JSON string to the POST fields */
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    /* set the content type json */
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

    /* set return type json */
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    /* execute request */
    return curl_exec($ch);
}
?>


<?php 
print $_SESSION['email'];
print $_SESSION['pass'];

//session_start();
  if (isset($_SESSION['email'])) 
  {
    if(isset($_SESSION['pass']))
    {
        $data = ["email" => $_SESSION['email'],"pass" => $_SESSION['pass'],"pergunta" => $_POST["pergunta"],"resposta1" => $_POST["resposta1"],"resposta2" => $_POST["resposta2"],"resposta3" => $_POST["resposta3"],"resposta4" => $_POST["resposta4"]];
        post('http://votenowapi.zapto.org/createperg/',$data);
        

        header("Location: " . "desh.php");


    }else{header("Location: " . "login.php");}
  }else{header("Location: " . "login.php");} 
  
?>
 