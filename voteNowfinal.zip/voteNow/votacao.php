<?php 
session_start();     
if(isset($_SESSION['email'])) 
{
  if(isset($_SESSION['pass']))
  {             
    $_SESSION["email"]=$_SESSION["email"];
    $_SESSION["pass"]=$_SESSION["pass"];
}
}
?>
<?php
function post($url,$data) {
    /* Init cURL resource */
    $ch = curl_init($url);

    /* pass encoded JSON string to the POST fields */
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    /* set the content type json */
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

    /* set return type json */
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    /* execute request */
    return curl_exec($ch);
}
?>

<?php
  if(session_id() === "log")
  {
    $_SESSION['log'] = 0;
    $email=null;
    $pass=null;
  }
  else
  {
    //$email=$_SESSION['email'];
    //$pass=$_SESSION['pass'];
  }  
?>

<?php
$id = $_POST['perg'];
         
$someJSON = file_get_contents('http://192.168.30.1:3010/pergunta/'.$id);        
if($someJSON == "Cannot GET /pergunta/")
{
  $redirect = $_SESSION["anterior"];
  if (empty($redirect)) {
  $_SESSION["anterior"]="votacao.php";
  $redirect ="index.php";
    }
  header("Location: " . $redirect);
}
else
{
$arr = json_decode($someJSON, true);


?>


<!DOCTYPE html>

<!--
 // WEBSITE: https://themefisher.com
 // TWITTER: https://twitter.com/themefisher
 // FACEBOOK: https://www.facebook.com/themefisher
 // GITHUB: https://github.com/themefisher/
-->

<html lang="zxx">

<head>
  <meta charset="utf-8">
  <title>Votação</title>

  <!-- mobile responsive meta -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  
  <!-- ** Plugins Needed for the Project ** -->
  <!-- plugins -->
  <link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="plugins/themify-icons/themify-icons.css">
  <!-- Main Stylesheet -->
  <link href="css/style.css" rel="stylesheet">
  
  <!--Favicon-->
  <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
  <link rel="icon" href="images/favicon.ico" type="image/x-icon">

</head>

<body>

<header class="sticky-top navigation">
  <div class=container>
    <nav class="navbar navbar-expand-lg navbar-light bg-transparent">
      <div>
		  <h3 href="index.php" id="heading-2">VoteNow</h3>
		  <a href="index.php" class="stretched-link"></a>
		</div>
      <button class="navbar-toggler border-0" type="button" data-toggle="collapse" data-target="#navigation">
        <i class="ti-align-right h4 text-dark"></i></button>
      <div class="collapse navbar-collapse text-center" id=navigation>
        <ul class="navbar-nav mx-auto align-items-center"></ul>
        <a href="desh.php" class="btn btn-sm btn-outline-primary ml-lg-4">Dashboard</a>
        <a href="login.php" class="btn btn-sm btn-primary ml-lg-4">Entrar</a>
      </div>
    </nav>
  </div>
</header>

<section class="section pb-0">
  <div class="container">
    <h2 class="mb-5 font-weight-medium">Titulo da votação</h2>
    <form class="row" method="post" action="funcaovoto.php">
      <!-- topic -->

      <?php for ($i = 0; $i < sizeof($arr); $i++) {?>
      <div class="col-lg-4 col-md-4 col-sm-6 mb-4">
        <div class="card match-height">
          <div class="card-body">

          
            <h3 class="card-text h4 text-center mb-4"><?php print $arr[$i]["respostas"];?></h3>
			      <button type="submit" name="voto" value="<?php echo $arr[$i]["respostas_id"] ?>" class="btn btn-primary">Votar</button>


          </div>
        </div>
      </div><?php } ?> 
    </form>
  </div>
</section>	

<footer>
  <div class="container">
    <div class="row align-items-center border-bottom py-5"></div>
    <div class="py-4 text-center">
      <small class="text-light">Copyright © 2020 a hugo theme by <a href="https://themefisher.com">themefisher</a></small>
    </div>
  </div>
</footer>
	
<!-- plugins -->
<script src="plugins/jQuery/jquery.min.js"></script>
<script src="plugins/bootstrap/bootstrap.min.js"></script>
<script src="plugins/masonry/masonry.min.js"></script>
<script src="plugins/clipboard/clipboard.min.js"></script>
<script src="plugins/match-height/jquery.matchHeight-min.js"></script>

<!-- Main Script -->
<script src="js/script.js"></script>

</body>
</html>

<?php } ?>