<?php 
session_start();     
if(isset($_SESSION['email'])) 
{
  if(isset($_SESSION['pass']))
  {             
    $_SESSION["email"]=$_SESSION["email"];
    $_SESSION["pass"]=$_SESSION["pass"];
}
}
?>
<?php

function post($url,$data) {
    /* Init cURL resource */
    $ch = curl_init($url);

    /* pass encoded JSON string to the POST fields */
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    /* set the content type json */
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

    /* set return type json */
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    /* execute request */
    return curl_exec($ch);
}
?>

<?php  
$data = [ "nome" => $_POST["nome"] , "email" => $_POST["email"] , "pass" => $_POST["pass"] ];
if(post('http://votenowapi.zapto.org/login/',$data) == "Cannot GET /registar/")
{
        header("Location: " . "login.php");
}
else
{
		post('http://votenowapi.zapto.org/registar/',$data);
    $_SESSION['log'] = 1;
    $_SESSION['email'] = $_POST["email"];
    $_SESSION['pass'] = $_POST["pass"];
    header("Location: " . "login.php");
}
?>